/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    LCD.h

  @Summary
    Brief description of the file.

  @Description
    cette librairy serre a la communication avec le ldc
 */
/* ************************************************************************** */
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "Mc32Delays.h"

#ifndef LCD    /* Guard against multiple inclusion */
#define LCD


void LCD_INIT(void);
void LCD_Commande(uint8_t Commende);
void LCD_Write(uint8_t Text);
void printf_lcd( const char *format,  ...);
void lcd_put_string (uint8_t* DataChar);
void lcd_gotoxy (uint8_t x, uint8_t y);
void lcd_clear(void);




#endif /* LCD */

/* *****************************************************************************
 End of File
 */

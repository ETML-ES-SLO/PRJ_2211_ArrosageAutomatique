/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/



// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "app.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "Capteur_Humidite.h"
#include "peripheral/adc/plib_adc.h"
#include "Arrosage.h"
#include "Capteur_hultrason.h"
#include "LCD.h"
#include "Gest_Menu.h"
#include "RTC.h"
#include "Mc32NVMUtil.h"
#include "GesPec12.h"



// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;

    
    /* TODO: Initialize your application's state machine and other
     * parameters.
     */
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{   
   //-- d�claration de variable --//  
   
   
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            //s'assurer que les l'electrovanne sois bien fermer 
            ELEC_VANN_1On();
            ELEC_VANN_2On();
            ELEC_VANN_3On();
            ELEC_VANN_4On();
            LED_ALARMOn();
            
            //initialisation des differante timer et module utiliser 
            LCD_INIT();
            Gest_Menu_Affiche();
            Pec12Init();
            DRV_IC0_Initialize();
            DRV_OC0_Initialize();
            DRV_TMR2_Initialize();
            DRV_TMR3_Initialize();
            DRV_TMR4_Initialize();
            DRV_TMR2_Start();
            DRV_TMR0_Start();
            DRV_TMR1_Start();
            DRV_TMR4_Start();
            INIT_RTC();
            ADC_INIT();
            Init_DataBuff();
            //lire si il y a des valeurs dans la memoirs
            Read_Data();             
            //lire la RTC
            Lecture_Paramettre();
            
            
            appData.state = APP_STATE_WAIT;

            break;
        }
        case APP_STATE_WAIT:
        {
           //attendre            
            break;
        }
        case APP_STATE_SERVICE_TASKS:
        {
            //faire la gestion des menu 
            Gest_Menu_Affiche();
            //mettre a 0 les valeur du PEC12
            Pec12ClearALL();

            //aller dans l etate d'attente 
            appData.state = APP_STATE_WAIT;
            break;
        }

        /* TODO: implement your application state machine.*/
        

        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}

void Save_Data(void)
{
   Save_Val Val_Save;
   //mettre toute les valeur a sauvgrader dans une variable de sauvgarde
   Val_Save.Alarm_Bac_1 = Alarm_Bac_1;
   Val_Save.Alarm_Bac_2 = Alarm_Bac_2;
   Val_Save.Alarm_Bac_3 = Alarm_Bac_3;
   Val_Save.Alarm_Bac_4 = Alarm_Bac_4;
   
   Val_Save.Consigne_Cap_Humi_bac1 = Humi_Sond_Consigne_bac1;
   Val_Save.Consigne_Cap_Humi_bac2 = Humi_Sond_Consigne_bac2;
   Val_Save.Consigne_Cap_Humi_bac3 = Humi_Sond_Consigne_bac3;
   Val_Save.Consigne_Cap_Humi_bac4 = Humi_Sond_Consigne_bac4;
   
   Val_Save.Consigne_temps_bac1 = Temps_Consigne_Bac_1;
   Val_Save.Consigne_temps_bac2 = Temps_Consigne_Bac_2;
   Val_Save.Consigne_temps_bac3 = Temps_Consigne_Bac_3;
   Val_Save.Consigne_temps_bac4 = Temps_Consigne_Bac_4;
   
   Val_Save.Cuve_Distance_Limite = Cuve_Distance_Limite;
   //mettre une valeur de recuperation
   Val_Save.Magic = 0x12345678;
   //sauvgarder les differante variable dans la flash du uC
   NVM_WriteBlock((uint32_t*)&Val_Save, sizeof(Val_Save));
    
}
void Read_Data(void)
{
   Save_Val Val_Save;
    //recuperer les valeur de la flash et les sauvgarder dans une variable de sauvgarde
    NVM_ReadBlock((uint32_t*)&Val_Save, sizeof(Val_Save));
    //si il y avais deja une sauvgarde
    if(Val_Save.Magic ==  0x12345678)
    {
        //si oui mettre les valeur sauvgarder dans les variable correspende
        Cuve_Distance_Limite = Val_Save.Cuve_Distance_Limite;
        Temps_Consigne_Bac_4 = Val_Save.Consigne_temps_bac4;
        Temps_Consigne_Bac_3 = Val_Save.Consigne_temps_bac3;
        Temps_Consigne_Bac_2 = Val_Save.Consigne_temps_bac2;
        Temps_Consigne_Bac_1 = Val_Save.Consigne_temps_bac1;
        Humi_Sond_Consigne_bac4 = Val_Save.Consigne_Cap_Humi_bac4;
        Humi_Sond_Consigne_bac3 = Val_Save.Consigne_Cap_Humi_bac3;
        Humi_Sond_Consigne_bac2 = Val_Save.Consigne_Cap_Humi_bac2;
        Humi_Sond_Consigne_bac1 = Val_Save.Consigne_Cap_Humi_bac1;
        Alarm_Bac_4 = Val_Save.Alarm_Bac_4;
        Alarm_Bac_3 = Val_Save.Alarm_Bac_3;
        Alarm_Bac_2 = Val_Save.Alarm_Bac_2;
        Alarm_Bac_1 = Val_Save.Alarm_Bac_1; 
    }
    else
    {
        //si non mettre les valeur par defaut 
        Init_Arrosage_Bac_1();
        Init_Arrosage_Bac_2();
        Init_Arrosage_Bac_3();
        Init_Arrosage_Bac_4();
        //mettre une limite a 25cm
        Cuve_Distance_Limite = 250;
    }
    
}

 void APP_UpdateState ( APP_STATES NewState )
{
    appData.state = NewState;
}
/*******************************************************************************
 End of File
 */

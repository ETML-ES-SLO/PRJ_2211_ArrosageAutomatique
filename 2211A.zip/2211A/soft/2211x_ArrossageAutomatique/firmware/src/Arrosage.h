/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    Arrosage.h

  @Summary
    Brief description of the file.

  @Description
    se ficher serre a gere l'arrosage
 */
/* ************************************************************************** */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "Capteur_Humidite.h"


#ifndef Arrosage    /* Guard against multiple inclusion */
#define Arrosage

extern uint16_t Temps_Bac_1;
extern uint16_t Temps_Bac_2;
extern uint16_t Temps_Bac_3;
extern uint16_t Temps_Bac_4;



typedef struct
{
    uint16_t X;
    uint16_t Y;
    uint16_t Z;
   
} Temps_Consigne;


extern Temps_Consigne Temps_Consigne_Bac_1;
extern Temps_Consigne Temps_Consigne_Bac_2;
extern Temps_Consigne Temps_Consigne_Bac_3;
extern Temps_Consigne Temps_Consigne_Bac_4;

extern STR_Val_Humi_Bac Humi_Sond_Consigne_bac1;
extern STR_Val_Humi_Bac Humi_Sond_Consigne_bac2;
extern STR_Val_Humi_Bac Humi_Sond_Consigne_bac3;
extern STR_Val_Humi_Bac Humi_Sond_Consigne_bac4;


void Init_Arrosage_Bac_1(void);
void Init_Arrosage_Bac_2(void);
void Init_Arrosage_Bac_3(void);
void Init_Arrosage_Bac_4(void);

void Start_Arrosage(uint8_t Num_Bac);

void Machine_etat_Arro(uint8_t Bac);

void Stop_Arrosage(uint8_t Num_Bac);
void Control_moteur(void);

#endif /* Arrosage */

/* *****************************************************************************
 End of File
 */

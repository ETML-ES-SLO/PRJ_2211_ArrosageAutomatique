/* ************************************************************************** */
/** Descriptive File Name

  @Company
  ETML-ES

  @File Name
    Capteur_Humidite.h

  @Summary
    Brief description of the file.

  @Description
     cette librairie serre a lire les ADC des capteur d'humiditer 
 */
/* ************************************************************************** */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "peripheral/adc/plib_adc.h"

#ifndef Capteur_Humidite    /* Guard against multiple inclusion */
#define Capteur_Humidite

typedef struct
{
    uint8_t Cap_1;
    uint8_t Cap_2;
    uint8_t Cap_3;
    bool Active;
} STR_Val_Humi_Bac;

typedef struct
{
    struct
    {
        uint8_t Cap_1;
        uint8_t Cap_2;
        uint8_t Cap_3;
    } Bac1;
    struct
    {
        uint8_t Cap_1;
        uint8_t Cap_2;
        uint8_t Cap_3;
    } Bac2;
    struct
    {
        uint8_t Cap_1;
        uint8_t Cap_2;
        uint8_t Cap_3;
    } Bac3;
    struct
    {
        uint8_t Cap_1;
        uint8_t Cap_2;
        uint8_t Cap_3;
    } Bac4;
} STR_Val_Humi_All_Bac;


STR_Val_Humi_Bac Lecture_BAC_Cap_Humi(uint8_t Num_Bac);

STR_Val_Humi_All_Bac Lecture_ALL_Cap_Humi(void);

void ADC_INIT(void);
void Contorle_Humi(void);

#endif /* Capteur_Humidite */



/* *****************************************************************************
 End of File
 */

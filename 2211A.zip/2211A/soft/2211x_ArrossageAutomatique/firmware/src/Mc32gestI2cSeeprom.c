//--------------------------------------------------------
// Mc32gestI2cEEprom.C
//--------------------------------------------------------
// Gestion I2C de la SEEPROM du MCP79411 (Solution exercice)
//	Description :	Fonctions pour EEPROM MCP79411
//
//	Auteur 		: 	C. HUBER
//      Date            :       26.05.2014
//	Version		:	V1.0
//	Compilateur	:	XC32 V1.31
// Modifications :
//
/*--------------------------------------------------------*/



#include "Mc32gestI2cSeeprom.h"
#include "Mc32_I2cUtilCCS.h"
#include "Mc32Delays.h"


// D�finition pour MCP79411
#define RTC_ADR_R    0x65        // MCP79411 address for read
#define RTC_ADR_W    0x64         // MCP79411 address for write


// Definitions du bus (pour mesures)
// #define I2C-SCK  SCL2/RA2      PORTAbits.RA2   pin 58
// #define I2C-SDA  SDa2/RA3      PORTAbits.RA3   pin 59




// Initialisation de la communication I2C et du MCP79411
// ------------------------------------------------

void I2C_Init(void)
{
   bool Fast = true;
   i2c_init( Fast );
} //end I2C_InitMCP79411


void I2C_Write(void *SrcData, uint32_t promAddr, uint16_t NbBytes)
{
    uint16_t i;
    uint16_t j;
    uint8_t* Point = SrcData;
    for(j = 0;j < NbBytes;j+=8)
    {
    i2c_start();
    i2c_write(RTC_ADR_W);
    i2c_write(promAddr+j);
    
    for(i = (promAddr%8); i < 8 ;i++)
    {
        i2c_write(*Point);
        Point++;
    }
    i2c_stop();
    delay_ms(5);
    }
} // end I2C_WriteSEEPROM

void I2C_Read(void *DstData, uint32_t promAddr, uint16_t NbBytes)
{
    uint16_t i;
    uint8_t* Point = DstData;
    i2c_start();
    i2c_write(RTC_ADR_W); 
    i2c_write(promAddr); 
    i2c_reStart();
    i2c_write(RTC_ADR_R); 
    for(i = 0; i < NbBytes-1;i++)
    {
        *Point = i2c_read(1);
        Point++;
    }
    *Point= i2c_read(0);
    i2c_stop();
} // end I2C_ReadSEEPROM
   





 




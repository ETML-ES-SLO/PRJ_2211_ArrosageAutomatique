/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    Capteur_hultrason.h

  @Summary
    Brief description of the file.

  @Description
     cette livrairie serre a gere le capteur a ultrason 
 */
/* ************************************************************************** */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_definitions.h"
#include "system_config.h"
#include "driver/oc/drv_oc_static.h"
#include "driver/ic/drv_ic_static.h"
#include "driver/tmr/drv_tmr_static.h" 
#include "Mc32Delays.h"


#ifndef Capteur_hultrason    /* Guard against multiple inclusion */
#define Capteur_hultrason
extern uint8_t Compt_OC;
extern double Distance_Pulse_1;
extern double Cuve_Distance_Limite;
void start_Lectrue_Dis(void);
void STOP_Lectrue_Dis(void);
void Save_Dis(uint16_t Temps_Dis);
bool controle_Pompe(void);
void alarme_On(void);
void alarme_Off(void);

#define Temp_lec_debit 10
extern double Val_debit;
extern double Volume_litre_reservoir;
void calcule_debit(void);

#endif /* Capteur_hultrason */

/* *****************************************************************************
 End of File
 */

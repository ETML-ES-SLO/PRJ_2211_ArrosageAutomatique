/* ************************************************************************** */
/** Descriptive File Name

  @Company
  ETML-ES

  @File Name
    Capteur_Humidite.c

  @Summary
    Brief description of the file.

  @Description
 cette librairie serre a lire les ADC des capteur d'humiditer 
 */
/* ************************************************************************** */
#include "Capteur_Humidite.h"
#include "peripheral/adc/plib_adc.h"
#include "driver/adc/drv_adc_static.h"
#include "Arrosage.h"

#define configscan  0x3ffC // SCAN AN2 -> AN14


void ADC_INIT(void)
{
    // Configure l'ADC
    PLIB_ADC_InputScanMaskAdd(ADC_ID_1, configscan);

    PLIB_ADC_ResultFormatSelect(ADC_ID_1, ADC_RESULT_FORMAT_INTEGER_16BIT);
    PLIB_ADC_ResultBufferModeSelect(ADC_ID_1, ADC_BUFFER_MODE_ONE_16WORD_BUFFER); //Modification: avant il �tait en mode 8 word et je pense qu'il s'agit du mode buffer altern� que je ne peux pas utiliser car trop d'entr�e analogique
    PLIB_ADC_SamplingModeSelect(ADC_ID_1, ADC_SAMPLING_MODE_MUXA);

    PLIB_ADC_ConversionTriggerSourceSelect(ADC_ID_1, ADC_CONVERSION_TRIGGER_INTERNAL_COUNT);    //Avant le mode de conversion �tait en internal ce qui signfie qu'on va continuer � lire le buffer en continue et on risque de commencer � lire pendant que
                                                                                                        //valeur se convertissent encore, je le passe en mode timer 3 pour r�guler 
    PLIB_ADC_VoltageReferenceSelect(ADC_ID_1, ADC_REFERENCE_VDD_TO_AVSS );
    PLIB_ADC_SampleAcquisitionTimeSet(ADC_ID_1, 0x1F);
    PLIB_ADC_ConversionClockSet(ADC_ID_1, SYS_CLK_FREQ, 32);

    // Rem CHR le nb d'�chantillon par interruption doit correspondre au nb d'entr�es
    // de la liste de scan
    PLIB_ADC_SamplesPerInterruptSelect(ADC_ID_1, ADC_12SAMPLES_PER_INTERRUPT);//Modifi� le nombre de sample pour 12 au lieu de 2
    PLIB_ADC_MuxAInputScanEnable(ADC_ID_1);

    // Enable the ADC module
    PLIB_ADC_Enable(ADC_ID_1);
}


STR_Val_Humi_Bac Lecture_BAC_Cap_Humi(uint8_t Num_Bac)
{
    //initialisation des variable
    STR_Val_Humi_Bac Val_Humi;
    STR_Val_Humi_All_Bac Val_LEC;
    
  
   //lire tout les ADC
   Val_LEC = Lecture_ALL_Cap_Humi();
    
    //savgarder juste le bac voulu
    switch(Num_Bac)
    {
        case 1:
            Val_Humi.Cap_1 = Val_LEC.Bac1.Cap_1;
            Val_Humi.Cap_2 = Val_LEC.Bac1.Cap_2;
            Val_Humi.Cap_3 = Val_LEC.Bac1.Cap_3;
    
            break;
        case 2:
            Val_Humi.Cap_1 = Val_LEC.Bac2.Cap_1;
            Val_Humi.Cap_2 = Val_LEC.Bac2.Cap_2;
            Val_Humi.Cap_3 = Val_LEC.Bac2.Cap_3;           
            break;
        case 3:
            Val_Humi.Cap_1 = Val_LEC.Bac3.Cap_1;
            Val_Humi.Cap_2 = Val_LEC.Bac3.Cap_2;
            Val_Humi.Cap_3 = Val_LEC.Bac3.Cap_3;    
            break;
        case 4:
            Val_Humi.Cap_1 = Val_LEC.Bac4.Cap_1;
            Val_Humi.Cap_2 = Val_LEC.Bac4.Cap_2;
            Val_Humi.Cap_3 = Val_LEC.Bac4.Cap_3;    
            break;
            
        default: 
            
            break;
    }

    //retourner le bac messurer
    return Val_Humi;
    
}
STR_Val_Humi_All_Bac Lecture_ALL_Cap_Humi(void)
{
    //initalisation des variable
    STR_Val_Humi_All_Bac Val_Humi;
    
    //sauvgarder tout les differant adc 
    Val_Humi.Bac1.Cap_1 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 0)*0.09765);//*0.09765 = 100/1024 (1024 = taille de la lecture et 100 echelle voulu)
    Val_Humi.Bac1.Cap_2 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 1)*0.09765);
    Val_Humi.Bac1.Cap_3 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 2)*0.09765);


    Val_Humi.Bac2.Cap_1 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 3)*0.09765);
    Val_Humi.Bac2.Cap_2 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 4)*0.09765);
    Val_Humi.Bac2.Cap_3 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 5)*0.09765);


    Val_Humi.Bac3.Cap_1 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 6)*0.09765);
    Val_Humi.Bac3.Cap_2 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 7)*0.09765);
    Val_Humi.Bac3.Cap_3 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 8)*0.09765);


    Val_Humi.Bac4.Cap_1 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 9)*0.09765);
    Val_Humi.Bac4.Cap_2 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 10)*0.09765);
    Val_Humi.Bac4.Cap_3 = 100-(PLIB_ADC_ResultGetByIndex(ADC_ID_1, 11)*0.09765);
    
    
    
    PLIB_ADC_SampleAutoStartEnable(ADC_ID_1);

    //retourner les valeur lue        
    return Val_Humi;
    
}

void Contorle_Humi(void)
{
    //initalitation des variable
    STR_Val_Humi_All_Bac Val_Bac;
    //si on utilise le controle de la sond 1 sur 1 bac
    if((Humi_Sond_Consigne_bac1.Active == true)||(Humi_Sond_Consigne_bac2.Active == true)||(Humi_Sond_Consigne_bac3.Active == true)|| (Humi_Sond_Consigne_bac4.Active == true))
    {
        
        //lecture de tout les bac
        Val_Bac = Lecture_ALL_Cap_Humi();
        //si le capteur 1 est plus sec que le seuil 
        if((Val_Bac.Bac1.Cap_1 <= Humi_Sond_Consigne_bac1.Cap_1 )&&(Humi_Sond_Consigne_bac1.Active == true))
        {
            //arrosage bac 1
            Start_Arrosage(1);
        }
        //si le capteur 1 est plus sec que le seuil 
        if((Val_Bac.Bac2.Cap_1 <= Humi_Sond_Consigne_bac2.Cap_1)&&(Humi_Sond_Consigne_bac2.Active == true))
        {
            //arrosage bac 2
            Start_Arrosage(2);
        }
        //si le capteur 1 est plus sec que le seuil 
        if((Val_Bac.Bac3.Cap_1 <= Humi_Sond_Consigne_bac3.Cap_1)&&(Humi_Sond_Consigne_bac3.Active == true))
        {
            //arrosage bac 3
            Start_Arrosage(3);
        }
        //si le capteur 1 est plus sec que le seuil 
        if((Val_Bac.Bac4.Cap_1 <= Humi_Sond_Consigne_bac4.Cap_1)&&(Humi_Sond_Consigne_bac4.Active == true))
        {
            //arrosage bac 4
            Start_Arrosage(4);
        }
    }
}
/* *****************************************************************************
 End of File
 */

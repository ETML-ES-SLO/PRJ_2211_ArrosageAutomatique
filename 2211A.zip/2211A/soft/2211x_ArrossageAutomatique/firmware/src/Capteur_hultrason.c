/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
 cette livrairie serre a gere le capteur a ultrason 
 */
/* ************************************************************************** */

#include "Capteur_hultrason.h"
#include <math.h>
//initalisation des variable
double Cuve_Distance_Limite;
double Distance_Pulse_1 = 0;
uint8_t Temp_Pulse_2 = 0;
uint8_t Temp_Pulse_3 = 0;
uint8_t Temp_Pulse_4 = 0;
uint8_t Compt_OC = 0;
double Val_debit;
double Volume_litre_reservoir;

void start_Lectrue_Dis(void)
{
    //activer OC0 
    Compt_OC = 1;
    DRV_OC0_Start();
    
    
}
void STOP_Lectrue_Dis(void)
{
    //stoper OC0
    DRV_IC0_Stop();
    DRV_OC0_Stop();
    
    
}

void Save_Dis(uint16_t Temps_Dis)
{
  static uint8_t Num_Capture = 0;
  //recuperation des differant interuption
  switch(Num_Capture)
  {
      case 0:
          //incrmenter le nombre de capture
          Num_Capture++;
          //savgarder la valeur lu en mm
          Distance_Pulse_1 = (Temps_Dis * 0.85);//0,85 = 340000/(400E3) en mm
          break;
      case 1:
          //incrmenter le nombre de capture
          Num_Capture++;
          //savgarder le temps de verification
          Temp_Pulse_2 = Temps_Dis;
          break;
      case 2:
          //incrmenter le nombre de capture
          Num_Capture++;
          //savgarder le temps de verification
          Temp_Pulse_3 = Temps_Dis;
          break;
      case 3:
          //remis a 0 de l'envois
          Num_Capture = 0;
          //stoper IC
          DRV_IC0_Stop();
          //savgarder le temps de verification
          Temp_Pulse_4 = Temps_Dis;
          break;
      default:
          break;
  }
    
}
bool controle_Pompe(void)
{
    //faire une lecture de distance
    start_Lectrue_Dis();
    
    //attendre 20ms que la lecture sois faite
    delay_ms(20);
    //si les 3 lecture de contole sont bon
    if(((Temp_Pulse_2 > 5) && (Temp_Pulse_2 < 15))&&((Temp_Pulse_3 > 5) && (Temp_Pulse_3 < 15))&&((Temp_Pulse_4 > 5) && (Temp_Pulse_4 < 15)))
    {
        //si la distance est plus petit que la limite
        if(Distance_Pulse_1 < Cuve_Distance_Limite)
        {
           //stoper l'alarme 
           alarme_Off();
           //dire que la pompe peu etre utiliser
           return true; 
        }
        else
        {
            //activer l'alarme
           alarme_On(); 
           //dire que la pompe ne peu pas etre utiliser
           return false;  
           
        }
    }
    else
    {
       //dire que la pompe ne peu pas etre utiliser
       return false; 
    }
}

void alarme_On(void)
{
    //activer le timer 4
    DRV_TMR4_Start();
    
}
void alarme_Off(void)
{
    //stoper le timer 4
    DRV_TMR4_Stop();
}

void calcule_debit(void)
{
    //calcule pour le debit
    double New_distance_debit;
    double New_volume_litre;
    
    
    //faire une lecture 
    start_Lectrue_Dis();
    //attendre 20ms que la lecture sois faite
    delay_ms(20);
    //sauvragder la distance pour le calcule en decimetre pour pouvoir avoir un debit en litre 
    New_distance_debit = Distance_Pulse_1 / 100;
    //V_mesure = 1/3*pi*(r_base^2+?((H_tot-H_mesurer)*Pente)?^2+((H_tot-H_mesurer)*Pente*r_base ))*Hmesurer
    New_volume_litre =  ((M_PI/3)*(1.96+sqrtl(10 - (New_distance_debit*5))+((10 - (New_distance_debit*5)*1.4)))*New_distance_debit);
    //faire le calcule avec une lecture qui se fait tout les Temp_lec_debit sec
    Val_debit = ((Volume_litre_reservoir - New_volume_litre)/Temp_lec_debit);
    Volume_litre_reservoir = New_volume_litre;
    
}
/* *****************************************************************************
 End of File
 */

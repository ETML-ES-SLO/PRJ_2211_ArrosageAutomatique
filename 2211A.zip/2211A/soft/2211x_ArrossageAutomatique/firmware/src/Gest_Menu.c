/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    Gest_Menu.c

  @Summary
    Brief description of the file.

  @Description
 cette librairy serre a faire le menu et les differant sous menu
 */
/* ************************************************************************** */

#include "Gest_Menu.h"
#include "GesPec12.h"
#include "RTC.h"
#include "Mc32DriverAdc.h"


//initalisation des variable
static S_ParamALARM Val_Mod_Alarme;
static uint8_t Sond_Choix;
static uint8_t Bac_Choix =1;
static uint8_t Menu_Affiche = INIT;
static uint16_t Choix_Temps;
static STR_Val_Humi_Bac New_Consigne_bac;
static Temps_Consigne New_Temps_Consigne;

bool Besoin_pompe = 0;

//gestion des differant sos menu
void Gest_Menu_Affiche(void)
{
    //effacer LCD
    lcd_clear();
    //menu afficher 
    switch(Menu_Affiche)
    {
        case INIT: 
            //aller dans le menu d'init
            Menu_Init();
            break;
        case REGLAGE: 
            //aller dans le menu de base
            Menu_Reglage();
            break;
        case CONF: 
            //aller dans le menu de configuration
            Menu_Conf();
            break;
        case CAPTEUR: 
            //aller dans le menu de lecture de capteur et de la RTC
            Menu_Capteur();
            break;
        case CONTROL: 
            //aller dans le menur pour controler manuellement les electrovanne et la pompe
            Menu_Controle();
            break;
        case LEC_BAC: 
            //aller dans le menu pour lire la valeur d'un bac
            Menu_Lecture_Bac();
            break;
        case CONFI_BAC: 
            //aller dans le menu pour configuer les consigne d'un bac
            Menu_Confi_BAC();
            break;  
        case CONFI_DIST: 
            //aller dans le menu pour choisir la limit du capteur de distance
            Menu_Confi_Distance();
            break;  
        case MODIF_BAC_SOND: 
            //aller dans le menu pour modifier la consigne d'une sonde
            Menu_Mofid_Bac_Sond();
            break;
        case MODIF_BAC_TEMPS_ARRO: 
            //aller dans le menu pour modifier le temps d'arrosage
            Menu_Mofid_Bac_Temps_Arro();
            break;        
        case MODIF_ALARM: 
            //aller dans le menu pour modifier les heur d'arrosage
            Menu_Mofid_Alarm();
            break;  
        case LEC_TEMPS:     
            //aller dans le menu pour lire l'heurs
            Menu_Lecture_Temp();
            break; 
        case CONFI_TEMPS:     
            //aller dans le menu pour modifier l heurs de la rtc
            Menu_Conf_Temps();
            break;     
        case CONFI_TEMPS_Sec:     
            //aller dans le menu pour modifier les seconde de la rtc
            Menu_Conf_Temps_Sec();
            break;     
        case CONFI_TEMPS_Min:     
            //aller dans le menu pour modifier les minute de la rtc
            Menu_Conf_Temps_Min();
            break;     
        case CONFI_TEMPS_Heu:     
            //aller dans le menu pour modifier l'heur de la rtc
            Menu_Conf_Temps_Heu();
            break;     
        case CONFI_TEMPS_SEM:     
            //aller dans le menu pour modifier le joure de la semaine de la rtc
            Menu_Conf_Temps_Sem();
            break;     
        case CONFI_TEMPS_Day:     
            //aller dans le menu pour modifier le jour de la rtc
            Menu_Conf_Temps_Day();
            break;     
        case CONFI_TEMPS_MOI:     
            //aller dans le menu pour modifier le mois de la rtc
            Menu_Conf_Temps_Moi();
            break;     
        case CONFI_TEMPS_ANN:     
            //aller dans le menu pour modifier l annee de la rtc
            Menu_Conf_Temps_Ann();
            break;  
        case CONFI_ALARM_SEM:     
            //aller dans le menu pour modifier le jour de la semaine de l'alarme
            Menu_Conf_ALARM_Sem();
            break;     
        case CONFI_ALARM_Heu:     
            //aller dans le menu pour modifier l'heurs de l'alarme
            Menu_Conf_ALARM_Heu();
            break;     
        case CONFI_ALARM_Min:     
            //aller dans le menu pour modifier la minut de l'alarme 
            Menu_Conf_ALARM_Min();
            break;  
        default: 
            break;
            
    }
    
    
}

void Menu_Init(void)
{
    //afficher le menu a l'initalisation du programme 
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("2211x");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("Arrosage Automat");
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("Marc Decrausaz");
    Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
}

void Menu_Reglage(void)
{
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
    //menu pour afficher l ecrant de bas du code
    switch (Menu_select)
    {
        case 0:
            //zonne pour choisir la configuration
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("> Configuration");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("  Capteurs");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Controle manul"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               
                Menu_Affiche = CONF; //aller dans le menu de configuration
            }
            break;
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Configuration");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Capteurs");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Controle manul"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CAPTEUR; //aller dans le menu de lecture des capteurs
            }
            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Configuration");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("  Capteurs");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("> Controle manul"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONTROL; //aller dans le menu de controle manuelle des electrovanne et de la pompe
            }
            break;
            
    }

}
void Menu_Capteur(void)
{
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
     
    switch (Menu_select)
    {
        case 0:
            start_Lectrue_Dis(); //lire la distance avec du capteur de distance
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("Lecture capteur");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Dis : %0.2fmm", Distance_Pulse_1);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Bac 1"); 

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               STOP_Lectrue_Dis(); //arreter de lire la distance du catpeur de distance
               Menu_select = 8; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }

            break;
        case 1:
            start_Lectrue_Dis(); //lire la distance avec du capteur de distance
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Dis : %0.2fmm", Distance_Pulse_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Bac 1");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Bac 2");
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                STOP_Lectrue_Dis(); //arreter de lire la distance du catpeur de distance
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                STOP_Lectrue_Dis(); //arreter de lire la distance du catpeur de distance
                Bac_Choix = 1; // choisir le bac 1 
                Menu_Affiche = LEC_BAC; //aller dans le menu pour lire les valeur du bac choisi
            }

            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Bac 1");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Bac 2");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Bac 3"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Bac_Choix = 2; // choisir le bac 2 
                Menu_Affiche = LEC_BAC; //aller dans le menu pour lire les valeur du bac choisi
            }

            break;
             
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Bac 2");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Bac 3");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Bac 4"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Bac_Choix = 3; // choisir le bac 3 
                Menu_Affiche = LEC_BAC; //aller dans le menu pour lire les valeur du bac choisi
            }

            break;
        case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Bac 3");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Bac 4");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Lecture Temp"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 5; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Bac_Choix = 4; // choisir le bac 4 
                Menu_Affiche = LEC_BAC; //aller dans le menu pour lire les valeur du bac choisi
            }

            break;
            case 5:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Bac 4");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Lecture Temp");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Capa max 27.5l"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 6; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = LEC_TEMPS; //aller dans le menur pour lire le temps sur la rtc
            }

            break;
                        case 6:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Lecture Temp");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Capa max 27.5l");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  eau rest %0.2fl",Volume_litre_reservoir); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 5; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 7; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                
            }

            break;
            case 7:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Capa max 27.5l");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> eau rest %0.2fl",Volume_litre_reservoir);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  debit %0.2fl/s",Val_debit); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 6; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 8; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               
            }
    
            break;
            case 8:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  eau rest %0.2fl",Volume_litre_reservoir);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> debit %0.2fl/s",Val_debit);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  "); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 7; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               
            }
            break;
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        STOP_Lectrue_Dis(); //arreter de lire la distance du catpeur de distance 
        Menu_select = 0; //re mettre a 0 le menu
        Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
    }
}
void Menu_Lecture_Bac()
{
    //afficher la valeur des capteur d'humiditer du bac choisi
    STR_Val_Humi_All_Bac Val_Humi;
    
    Val_Humi = Lecture_ALL_Cap_Humi(); // lecture de tout les capteur d'humidit�
    
    switch (Bac_Choix)
    {
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("sond 1 %d%%", Val_Humi.Bac1.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("sond 2 %d%%", Val_Humi.Bac1.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("sond 3 %d%%", Val_Humi.Bac1.Cap_3);
            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("sond 1 %d%%", Val_Humi.Bac2.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("sond 2 %d%%", Val_Humi.Bac2.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("sond 3 %d%%", Val_Humi.Bac2.Cap_3);
            break;
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("sond 1 %d%%", Val_Humi.Bac3.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("sond 2 %d%%", Val_Humi.Bac3.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("sond 3 %d%%", Val_Humi.Bac3.Cap_3);
            break;
        case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("sond 1 %d%%", Val_Humi.Bac4.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("sond 2 %d%%", Val_Humi.Bac4.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("sond 3 %d%%", Val_Humi.Bac4.Cap_3);
            break;
    }
    
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
       Menu_Affiche = CAPTEUR; //aller dans le menu de lecture des capteurs
    }
}



void Menu_Controle(void)
{
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
     
    switch (Menu_select)
    {
        case 0:
            
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("Controle Manuel");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Pompe ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Elecvanne 1"); 

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                if(Besoin_pompe == 0)
                {
                   Besoin_pompe = 1;  
                }
                else
                {
                   Besoin_pompe = 0; 
                }
                POMPE_HToggle();
                POMPE_RELAISToggle(); //activer ou desactiver la pompe
            }
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Pompe");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Elecvanne 1 ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Elecvanne 2"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               ELEC_VANN_1Toggle(); //activer ou desactiver l'electrovanne 
            }

            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Elecvanne 1");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Elecvanne 2 ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Elecvanne 3"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                ELEC_VANN_2Toggle();//activer ou desactiver l'electrovanne
            }

            break;
             
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Elecvanne 2");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Elecvanne 3 ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Elecvanne 4"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               ELEC_VANN_3Toggle();//activer ou desactiver l'electrovanne
            }

            break;
            case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Elecvanne 3");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Elecvanne 4 ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd(" "); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               ELEC_VANN_4Toggle();//activer ou desactiver l'electrovanne
            }

            break;
    } 
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        Menu_select = 0; //re mettre a 0 le menu
        Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
        ELEC_VANN_1On();
        ELEC_VANN_2On();
        ELEC_VANN_3On();
        ELEC_VANN_4On();
        POMPE_HOff();
        POMPE_RELAISOn();
    }
}

void Menu_Conf(void)
{
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
    switch (Menu_select)
    {
        case 0:
            
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("Configuration");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> humi bac 1");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  humi bac 2"); 

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 6; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_select = 0; //re mettre a 0 le menu
                Bac_Choix = 1; // choisir le bac 1 
                Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
                
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  humi bac 1");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> humi bac 2 ");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  humi bac 3"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_select = 0; //re mettre a 0 le menu
                Bac_Choix = 2; // choisir le bac 2 
                Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  humi bac 2");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> humi bac 3");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  humi bac 4"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_select = 0; //re mettre a 0 le menu
                Bac_Choix = 3; // choisir le bac 3 
                Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
             
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  humi bac 3");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> humi bac 4");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Capt Distance"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_select = 0; //re mettre a 0 le menu
               Bac_Choix = 4; // choisir le bac 4 
               Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
        case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  humi bac 4");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Capt Distance");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Temps RTC"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 5; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = CONFI_DIST; //aller dans le menu pour configuer la distance limit de bac a eau
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
        case 5:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Capt Distance");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Temps RTC");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Reset usine"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 6; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
            case 6:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Temps RTC");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Reset usine");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  "); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 5; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_select = 0; //re mettre a 0 le menu
                Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
                Init_Arrosage_Bac_1();
                Init_Arrosage_Bac_2();
                Init_Arrosage_Bac_3();
                Init_Arrosage_Bac_4();
                Cuve_Distance_Limite = 250;
                Save_Data();//sauvgarder les valeurs
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = REGLAGE; //aller dans le menu de base du programme
            }
            break;
    } 
}


void Menu_Confi_BAC(void)
{
   
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
    static uint8_t save_Cons = 0;

    if(save_Cons == 0)
    {
        switch(Bac_Choix)
        {
            case 1:
                New_Consigne_bac = Humi_Sond_Consigne_bac1;
                New_Temps_Consigne = Temps_Consigne_Bac_1;
                break;
            case 2:
                New_Consigne_bac = Humi_Sond_Consigne_bac2;
                New_Temps_Consigne = Temps_Consigne_Bac_2;
                break;
            case 3:
                New_Consigne_bac = Humi_Sond_Consigne_bac3;
                New_Temps_Consigne = Temps_Consigne_Bac_3;
                break;
            case 4:
                New_Consigne_bac = Humi_Sond_Consigne_bac4;
                New_Temps_Consigne = Temps_Consigne_Bac_4;
                break;
            default:       
                break;
        }
        
        save_Cons = 1;
    }
    
    switch (Menu_select)
    {
        case 0:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            //affichage selon le bac choisi
            switch(Bac_Choix)
            {
                case 1:
                    printf_lcd("> Test bac 1");
                    break;
                case 2:
                    printf_lcd("> Test bac 2");
                    break;
                case 3:
                    printf_lcd("> Test bac 3");
                    break;
                case 4:
                    printf_lcd("> Test bac 4");
                    break;
                default:

                    break;
            }
            
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("  Sond 1 %d%%",New_Consigne_bac.Cap_1);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Sond 2 %d%%",New_Consigne_bac.Cap_2); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 8; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                //enregistrer les valeur pour faire un arrosage
                switch(Bac_Choix)
                {
                    case 1:
                        Humi_Sond_Consigne_bac1 = New_Consigne_bac ;
                        Temps_Consigne_Bac_1 = New_Temps_Consigne;
                        break;
                    case 2:
                        Humi_Sond_Consigne_bac2 = New_Consigne_bac;
                        Temps_Consigne_Bac_2 = New_Temps_Consigne;
                        break;
                    case 3:
                        Humi_Sond_Consigne_bac3 = New_Consigne_bac;
                        Temps_Consigne_Bac_3 = New_Temps_Consigne;
                        break;
                    case 4:
                        Humi_Sond_Consigne_bac4 = New_Consigne_bac;
                        Temps_Consigne_Bac_4 = New_Temps_Consigne;
                        break;
                    default:

                        break;
                }
                //commencer un arrosage
                Start_Arrosage(Bac_Choix);
            }

            break;
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("> Sond 1 %d%%",New_Consigne_bac.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("  Sond 2 %d%%",New_Consigne_bac.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Sond 3 %d%%",New_Consigne_bac.Cap_3); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Sond_Choix = 1; //chosi la sonde 1
               Menu_Affiche = MODIF_BAC_SOND; //modifi la valeur de consigne de la sonde choisi
            }

            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Sond 1 %d%%",New_Consigne_bac.Cap_1);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Sond 2 %d%%",New_Consigne_bac.Cap_2);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Sond 3 %d%%",New_Consigne_bac.Cap_3); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Sond_Choix = 2; //chosi la sonde 2
               Menu_Affiche = MODIF_BAC_SOND; //modifi la valeur de consigne de la sonde choisi
            }

            break;
            case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Sond 2 %d%%",New_Consigne_bac.Cap_2);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Sond 3 %d%%",New_Consigne_bac.Cap_3);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  T arro 1 %ds",New_Temps_Consigne.X); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Sond_Choix = 3; //chosi la sonde 3
               Menu_Affiche = MODIF_BAC_SOND; //modifi la valeur de consigne de la sonde choisi
            }

            break;  
            case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Sond 3 %d%%",New_Consigne_bac.Cap_3);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> T arro 1 %ds", New_Temps_Consigne.X);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  T att    %ds", New_Temps_Consigne.Y); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 5; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Choix_Temps = 1; //choisi quelle temps on veux modifier
               Menu_Affiche = MODIF_BAC_TEMPS_ARRO;  //aller dans le menu pour modifier le temp choisi
            }

            break;  
            case 5:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  T arro 1 %ds", New_Temps_Consigne.X);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> T att    %ds", New_Temps_Consigne.Y);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  T arro 2 %ds", New_Temps_Consigne.Z); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 6; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Choix_Temps = 2; //choisi quelle temps on veux modifier
               Menu_Affiche = MODIF_BAC_TEMPS_ARRO;  //aller dans le menu pour modifier le temp choisi
            }

            break;  
            case 6:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  T att    %ds", New_Temps_Consigne.Y);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> T arro 2 %ds", New_Temps_Consigne.Z);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  alarme Arro"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 5; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 7; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Choix_Temps = 3; //choisi quelle temps on veux modifier
               Menu_Affiche = MODIF_BAC_TEMPS_ARRO;  //aller dans le menu pour modifier le temp choisi
            }

            break; 
            case 7:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  T arro 2 %ds", New_Temps_Consigne.Z);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> alarme Arro");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            if(New_Consigne_bac.Active == true)
            {
                printf_lcd("  auto arr actif"); 
            }
            else
            {
               printf_lcd("  auto arr deact");   
            }
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 6; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 8; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               
               Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme 
            }

            break; 
            case 8:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  alarme Arro");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            
            if(New_Consigne_bac.Active == true)
            {
                printf_lcd("> auto arr actif"); 
            }
            else
            {
               printf_lcd("> auto arr deact");   
            }
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  ");
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 7; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                if(New_Consigne_bac.Active == true)
                {
                    New_Consigne_bac.Active = false;
                }
                else
                {
                   New_Consigne_bac.Active = true;
                }
               
            }

            break; 
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
         switch(Bac_Choix)
        {
            case 1:
                Humi_Sond_Consigne_bac1 = New_Consigne_bac ;
                Temps_Consigne_Bac_1 = New_Temps_Consigne;
                break;
            case 2:
                Humi_Sond_Consigne_bac2 = New_Consigne_bac;
                Temps_Consigne_Bac_2 = New_Temps_Consigne;
                break;
            case 3:
                Humi_Sond_Consigne_bac3 = New_Consigne_bac;
                Temps_Consigne_Bac_3 = New_Temps_Consigne;
                break;
            case 4:
                Humi_Sond_Consigne_bac4 = New_Consigne_bac;
                Temps_Consigne_Bac_4 = New_Temps_Consigne;
                break;
            default:

                break;
        }
        Stop_Arrosage(Bac_Choix); //arreter l'arrosage du bac choisi
        Menu_select = 0; //re mettre a 0 le menu
        Save_Data();//sauvgarder les valeurs
        Menu_Affiche = CONF; //aller dans le menu de configuration
        
    }
}


void Menu_Mofid_Bac_Sond(void)
{
    static uint8_t New_Consigne;
    static uint8_t Val_Sav;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        switch(Sond_Choix)
        {
            case 1:
               
                Val_Sav = New_Consigne_bac.Cap_1;
                break;
            case 2:
               
                Val_Sav = New_Consigne_bac.Cap_2;
                break;
            case 3:
                
                Val_Sav = New_Consigne_bac.Cap_3;
                break;
            default:

                break;
        }
        New_Consigne = Val_Sav;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd(" ");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %d%%",Val_Sav);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %d%%", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 100)
        {
            New_Consigne += 1;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
        switch(Sond_Choix)
        {
            case 1:
                New_Consigne_bac.Cap_1 = New_Consigne;
                break;
            case 2:
                New_Consigne_bac.Cap_2 = New_Consigne;
                break;
            case 3:
                New_Consigne_bac.Cap_3 = New_Consigne;
                break;
            default:

                break;
        }
      Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
    }
}

void Menu_Mofid_Bac_Temps_Arro(void)
{
    static uint16_t New_Consigne;
    static uint16_t Val_Sav;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        switch(Choix_Temps)
        {
            case 1:

                Val_Sav = New_Temps_Consigne.X;
                break;
            case 2:
                
                Val_Sav = New_Temps_Consigne.Y;
                break;
            case 3:
               
                Val_Sav = New_Temps_Consigne.Z;
                break;
            default:

                break;
        }
    New_Consigne = Val_Sav;
    save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd(" ");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %ds",Val_Sav);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %ds", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
            New_Consigne += 1;
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
        save_Cons = 0;
        switch(Choix_Temps)
        {
            case 1:
                New_Temps_Consigne.X = New_Consigne;
                break;
            case 2:
                New_Temps_Consigne.Y = New_Consigne;
                break;
            case 3:
                New_Temps_Consigne.Z = New_Consigne;
                break;
            default:

                break;
        }
      
      Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
    }
    
}
void Menu_Mofid_Alarm(void)
{
 static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
 static uint8_t Menu_Start = 0;

    if(Menu_Start == 0)
    {
        Menu_Start = 1;
        Lecture_Paramettre(); 
        switch(Bac_Choix)
        {
            case 1:
                Val_Mod_Alarme = Alarm_Bac_1;
                break;
            case 2:
                Val_Mod_Alarme = Alarm_Bac_2;
                break;
            case 3:
                Val_Mod_Alarme = Alarm_Bac_3;
                break;
            case 4:
                Val_Mod_Alarme = Alarm_Bac_4;
                break;
            default:
                        
                break;
        }
        
    }
  
    switch (Menu_select)
    {
        case 0:
            
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            switch(Bac_Choix)
            {
                case 1:
                    printf_lcd("Config alarme 1");
                    break;
                case 2:
                    printf_lcd("Config alarme 2");
                    break;
                case 3:
                    printf_lcd("Config alarme 3");
                    break;
                case 4:
                    printf_lcd("Config alarme 4");
                    break;
                default:

                    break;
            }
            
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Heur : %02d", Val_Mod_Alarme.HEU);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Min : %02d", Val_Mod_Alarme.MIN); 

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_ALARM_Heu; //aller dans le menu pour modifier l'heur de l'alarme
            }
            break;
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Heur : %02d", Val_Mod_Alarme.HEU);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Min : %02d", Val_Mod_Alarme.MIN);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            switch (Val_Mod_Alarme.SEM)
            {
                case Lundi:
                    printf_lcd("  Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("  Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("  Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("  Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("  Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("  Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("  Jour Sem : Dim");
                    break;
                default:
                    printf_lcd("  Jour Sem : Pas");
                    break;
            }
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_ALARM_Min;//aller dans le menu pour modifier les minute de l'alarme
            }
            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Min : %02d", Val_Mod_Alarme.MIN);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
             switch (Val_Mod_Alarme.SEM)
            {
                case Lundi:
                    printf_lcd("> Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("> Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("> Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("> Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("> Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("> Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("> Jour Sem : Dim");
                    break;
                default:
                    printf_lcd("  Jour Sem : Pas");
                    break;
            }
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            if(Val_Mod_Alarme.ACTIF == true)
            {
                printf_lcd("  Alarme activer");
            }
            else
            {
                printf_lcd("  Alarme deactiv");
            }

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
               Menu_Affiche =  CONFI_ALARM_SEM;//aller dans le menu pour modifier les joure de la semaine de l'alarme
            }
            break;
             
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            switch (Val_Mod_Alarme.SEM)
            {
                case Lundi:
                    printf_lcd("  Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("  Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("  Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("  Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("  Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("  Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("  Jour Sem : Dim");
                    break;
                default:
                    printf_lcd("  Jour Sem : Pas");
                    break;
                    
            }
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            if(Val_Mod_Alarme.ACTIF == true)
            {
                printf_lcd("> Alarme activer");
            }
            else
            {
                printf_lcd("> Alarme deactiv");
            }

            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Validation"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                if(Val_Mod_Alarme.ACTIF == true)
                {
                 Val_Mod_Alarme.ACTIF = false;
                }
                else
                {
                Val_Mod_Alarme.ACTIF = true;
                }
            }
            break;
        case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            if(Val_Mod_Alarme.ACTIF == true)
            {
                printf_lcd("  Alarme activer");
            }
            else
            {
                printf_lcd("  Alarme deactiv");
            }

            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
             printf_lcd("> Validation");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd(" "); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                switch(Bac_Choix)
                {
                    case 1:
                        Alarm_Bac_1 = Val_Mod_Alarme;
                        break;
                    case 2:
                        Alarm_Bac_2 = Val_Mod_Alarme;
                        break;
                    case 3:
                        Alarm_Bac_3 = Val_Mod_Alarme;
                        break;
                    case 4: 
                        Alarm_Bac_4 = Val_Mod_Alarme;
                        break;
                    default:
                        break;
                }
                Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
                Menu_select = 0; //re mettre a 0 le menu
                Menu_Start = 0;
            }
            break;
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        Menu_Affiche = CONFI_BAC; //aller dans le menu pour configuer le bac choisi
        Menu_select = 0; //re mettre a 0 le menu
        Menu_Start = 0;
    } 
}



void Menu_Confi_Distance(void)
{
    static double New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Cuve_Distance_Limite;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("distance limit");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %0.0fmm",Cuve_Distance_Limite);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %0.0fmm", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
   
            New_Consigne += 1;

    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
          
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Cuve_Distance_Limite = New_Consigne;
      Save_Data();//sauvgarder les valeurs
      Menu_Affiche = CONF; //aller dans le menu de configuration
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
       save_Cons = 0;
       Menu_Affiche = CONF; //aller dans le menu de configuration
    } 
    
}


void Menu_Lecture_Temp(void)
{
     
    Lecture_Paramettre();
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("%02d/%02d/20%02d",Local_Para.JOU,Local_Para.MOI,Local_Para.ANN);
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    switch (Local_Para.SEM)
    {
        case Lundi:
            printf_lcd("Lundi");
            break;
        case Mardi:
            printf_lcd("Mardi");
            break;
        case Mercredi:
            printf_lcd("Mercredi");  
            break;
        case Jeudi:
            printf_lcd("Jeudi");
            break;
        case Vendredi:
            printf_lcd("Vendredi");    
            break;
        case Samedi:
            printf_lcd("Samedi");
            break;
        case Dimanche:
            printf_lcd("Dimanche");   
            break;
    }
    
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("%02d:%02d:%02d",Local_Para.HEU,Local_Para.MIN,Local_Para.SEC);
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        Menu_Affiche = CAPTEUR; //aller dans le menu de lecture des capteurs
    } 
}
 
static S_ParamTemp Val_Mod;

void Menu_Conf_Temps(void)
{
    static uint8_t Menu_select = 0; //initaliser une variable pour savoir dans quelle affichage on se trouve
    static uint8_t Menu_Start = 0;
    if(Menu_Start == 0)
    {
        Menu_Start = 1;
        Lecture_Paramettre(); 
        Val_Mod = Local_Para;
    }
    switch (Menu_select)
    {
        case 0:
            
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("Config Temps");
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Ann : 20%02d", Val_Mod.ANN);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Mois : %02d", Val_Mod.MOI); 

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 7; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 1; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_ANN;//aller dans le menu pour configuer le l'anner dans la rtc
            }
            break;
        case 1:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Ann : 20%02d", Val_Mod.ANN);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Mois : %02d", Val_Mod.MOI);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Jour : %02d", Val_Mod.JOU);
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                
                Menu_select = 2; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_MOI; //aller dans le menu pour configurer le mois dans la rtc
            }
            break;
        case 2:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Mois : %02d", Val_Mod.MOI);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Jour : %02d", Val_Mod.JOU);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            switch (Val_Mod.SEM)
            {
                case Lundi:
                    printf_lcd("  Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("  Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("  Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("  Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("  Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("  Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("  Jour Sem : Dim");
                    break;
            }

            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 1; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                
                Menu_select = 3; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_Day; //aller dans le menu pour modifier le jour de la rtc
            }
            break;
             
        case 3:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Jour : %02d", Val_Mod.JOU);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            switch (Val_Mod.SEM)
            {
                case Lundi:
                    printf_lcd("> Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("> Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("> Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("> Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("> Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("> Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("> Jour Sem : Dim");
                    break;
            }
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Heur : %02d", Val_Mod.HEU); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 2; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 4; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_SEM; //aller dans le menu pour modifier le joure de la semaine de la rtc
            }
            break;
        case 4:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            switch (Val_Mod.SEM)
            {
                case Lundi:
                    printf_lcd("  Jour Sem : Lun");
                    break;
                case Mardi:
                    printf_lcd("  Jour Sem : Mar");
                    break;
                case Mercredi:
                    printf_lcd("  Jour Sem : Mer"); 
                    break;
                case Jeudi:
                    printf_lcd("  Jour Sem : Jeu");
                    break;
                case Vendredi:
                    printf_lcd("  Jour Sem : Ven");    
                    break;
                case Samedi:
                    printf_lcd("  Jour Sem : Sam");
                    break;
                case Dimanche:
                    printf_lcd("  Jour Sem : Dim");
                    break;
            }
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Heur : %02d", Val_Mod.HEU); 
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Min : %02d", Val_Mod.MIN); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 3; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 5; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_Heu; //aller dans le menu pour modifier l'heurs dans la rtc
            }
            break;
            case 5:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Heur : %02d", Val_Mod.HEU);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Min : %02d", Val_Mod.MIN);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Sec : %02d", Val_Mod.SEC); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 4; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 6; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_Min; //aller dans le menu pour modifier les minute dans la rtc
            }
            if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
            {
               Menu_select = 0; //re mettre a 0 le menu
               Menu_Affiche = CONF; //aller dans le menu de configuration
            }
            break;
            case 6:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Min : %02d", Val_Mod.MIN);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Sec : %02d", Val_Mod.SEC);
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  Validation"); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 5; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 7; 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONFI_TEMPS_Sec; //aller dans le menu pour modifier les seconde dans la rtc
            }
            break;
            case 7:
            lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
            printf_lcd("  Sec : %02d", Val_Mod.SEC);
            lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
            printf_lcd("> Validation");
            lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
            printf_lcd("  "); 
            if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
            {
               Menu_select = 6; 
            }
            if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
            {
                Menu_select = 0; //re mettre a 0 le menu 
            }
            if(Pec12IsOK()) //si PEC12 appuyer ok
            {
                Menu_Affiche = CONF; //aller dans le menu de configuration
                Menu_select = 0; //re mettre a 0 le menu
                Write_Paramettre_RTC(Val_Mod); //ecrire dans la RTC les valeur choisi
                Menu_Start = 0;
            }
            break;
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
       Menu_select = 0; //re mettre a 0 le menu
       Menu_Start = 0;
       Menu_Affiche = CONF; //aller dans le menu de configuration
       
    }
}
void Menu_Conf_Temps_Sec(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.SEC;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Sec");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod.SEC);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 59)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 59;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.SEC = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}
void Menu_Conf_Temps_Min(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.MIN;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Min");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod.MIN);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 59)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 59;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.MIN = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}
void Menu_Conf_Temps_Heu(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.HEU;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Heu");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod.HEU);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 23)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 23;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.HEU = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}
void Menu_Conf_Temps_Sem(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.SEM;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur du jour");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    switch (Val_Mod.SEM)
    {
    case Lundi:
        printf_lcd("OLD cons Lundi");
        break;
    case Mardi:
        printf_lcd("OLD cons Mardi");
        break;
    case Mercredi:
        printf_lcd("OLD cons Mercred"); 
        break;
    case Jeudi:
        printf_lcd("OLD cons Jeudi");
        break;
    case Vendredi:
        printf_lcd("OLD cons Vendred");    
        break;
    case Samedi:
        printf_lcd("OLD cons Samedi");
        break;
    case Dimanche:
        printf_lcd("OLD cons Dimanch");
        break;
    }
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    switch (New_Consigne)
    {
    case Lundi:
        printf_lcd("NEW cons Lundi");
        break;
    case Mardi:
        printf_lcd("NEW cons Mardi");
        break;
    case Mercredi:
        printf_lcd("NEW cons Mercred"); 
        break;
    case Jeudi:
        printf_lcd("NEW cons Jeudi");
        break;
    case Vendredi:
        printf_lcd("NEW cons Vendred");    
        break;
    case Samedi:
        printf_lcd("NEW cons Samedi");
        break;
    case Dimanche:
        printf_lcd("NEW cons Dimanch");
        break;
    }
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 0x40)
        {
            New_Consigne = New_Consigne<< 1;
        }
        else
        {
            New_Consigne = 0x01;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0x01)
        {
            New_Consigne = New_Consigne >> 1;
        }
        else
        {
            New_Consigne = 0x40;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.SEM = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}
void Menu_Conf_Temps_Day(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.JOU;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Jour");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod.JOU);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 31)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 1;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 1)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 31;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.JOU = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }  
}
void Menu_Conf_Temps_Moi(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.MOI;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Mois");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod.MOI);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 12)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 1;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 1)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 12;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.MOI = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}
void Menu_Conf_Temps_Ann(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod.ANN;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Ann");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons 20%02d",Val_Mod.ANN);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons 20%02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 99)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 99;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod.ANN = New_Consigne;
      Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = CONFI_TEMPS; //aller dans le menu pour configuer le temps de la rtc
    } 
}


void Menu_Conf_ALARM_Min(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod_Alarme.MIN;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Min");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod_Alarme.MIN);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 59)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 59;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod_Alarme.MIN = New_Consigne;
      Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    } 
}
void Menu_Conf_ALARM_Heu(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod_Alarme.HEU;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur des Heu");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    printf_lcd("OLD cons %02d",Val_Mod_Alarme.HEU);
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    printf_lcd("NEW cons %02d", New_Consigne); 
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 23)
        {
            New_Consigne += 1;
        }
        else
        {
            New_Consigne = 0;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0)
        {
            New_Consigne -= 1;
        }
        else
        {
            New_Consigne = 23;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod_Alarme.HEU = New_Consigne;
      Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    } 
}
void Menu_Conf_ALARM_Sem(void)
{
    static uint16_t New_Consigne;
    static uint8_t save_Cons = 0;
    if(save_Cons == 0)
    {
        New_Consigne = Val_Mod_Alarme.SEM;
        save_Cons = 1;
    }
    lcd_gotoxy(0,1); //met le curseur du LCD en ligne 1
    printf_lcd("Valeur du jour");
    lcd_gotoxy(0,2); //met le curseur du LCD en ligne 2
    switch (Val_Mod_Alarme.SEM)
    {
    case Lundi:
        printf_lcd("OLD cons Lundi");
        break;
    case Mardi:
        printf_lcd("OLD cons Mardi");
        break;
    case Mercredi:
        printf_lcd("OLD cons Mercred"); 
        break;
    case Jeudi:
        printf_lcd("OLD cons Jeudi");
        break;
    case Vendredi:
        printf_lcd("OLD cons Vendredi");    
        break;
    case Samedi:
        printf_lcd("OLD cons Samedi");
        break;
    case Dimanche:
        printf_lcd("OLD cons Dimanche");
        break;
    }
    lcd_gotoxy(0,3); //met le curseur du LCD en ligne 3
    switch (New_Consigne)
    {
    case Lundi:
        printf_lcd("NEW cons Lundi");
        break;
    case Mardi:
        printf_lcd("NEW cons Mardi");
        break;
    case Mercredi:
        printf_lcd("NEW cons Mercredi"); 
        break;
    case Jeudi:
        printf_lcd("NEW cons Jeudi");
        break;
    case Vendredi:
        printf_lcd("NEW cons Vendredi");    
        break;
    case Samedi:
        printf_lcd("NEW cons Samedi");
        break;
    case Dimanche:
        printf_lcd("NEW cons Dimanche");
        break;
    }
    if(Pec12IsPlus()) //si pec 12 tourne en sense anti  horaire
    {
        if(New_Consigne < 0x40)
        {
            New_Consigne = New_Consigne<< 1;
        }
        else
        {
            New_Consigne = 0x01;
        }
    }
    if(Pec12IsMinus()) //si pec 12 tourne en sense horaire
    {
        if(New_Consigne > 0x01)
        {
            New_Consigne = New_Consigne >> 1;
        }
        else
        {
            New_Consigne = 0x40;
        }
    }
    if(Pec12IsOK()) //si PEC12 appuyer ok
    {
      save_Cons = 0;
      Val_Mod_Alarme.SEM = New_Consigne;
      Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    }
    if(Pec12IsESC()) //si le PEC12 est rester appuyer plus de 0.5sec
    {
        save_Cons = 0;
        Menu_Affiche = MODIF_ALARM; //aller dans le menu pour modifier l'alarme
    } 
}

/* *****************************************************************************
 End of File
 */

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    RTC.c

  @Summary
    Brief description of the file.

  @Description
 ce fichier serre a controler la RTC
 */
/* ************************************************************************** */
#include "RTC.h"
#include "Mc32gestI2cSeeprom.h"

S_ParamTemp Local_Para;
S_ParamALARM Alarm_Bac_1;
S_ParamALARM Alarm_Bac_2;
S_ParamALARM Alarm_Bac_3;
S_ParamALARM Alarm_Bac_4;


void INIT_RTC(void)
{
    //activer l'alarme en semaine avec une interuption qui dure 1 seconde et le timer desactiver 
    uint8_t config = 0x0A;
    I2C_Init();
    I2C_Write(&config,0x0D,sizeof(uint8_t));
    
   
}

// Lecture et �criture si des param�tres sont sauv�s
void Lecture_Paramettre(void)
{
    S_ParamTemp Lect_Param;
    I2C_Read(&Lect_Param ,0x00,sizeof(S_ParamTemp));
    Local_Para.SEC = (((Lect_Param.SEC >> 4) *10) + (Lect_Param.SEC % 16));
    Local_Para.MIN = (((Lect_Param.MIN >> 4) *10) + (Lect_Param.MIN % 16));
    Local_Para.HEU = (((Lect_Param.HEU >> 4) *10) + (Lect_Param.HEU % 16));
    Local_Para.SEM = Lect_Param.SEM;
    Local_Para.JOU = (((Lect_Param.JOU >> 4) *10) + (Lect_Param.JOU % 16));
    Local_Para.MOI = (((Lect_Param.MOI >> 4) *10) + (Lect_Param.MOI % 16));
    Local_Para.ANN = (((Lect_Param.ANN >> 4) *10) + (Lect_Param.ANN % 16));                                
 
}

void Write_Paramettre_RTC(S_ParamTemp ParaSave)
{
    S_ParamTemp Ecrit_Param;
    //modifier l'heurs dans la RTC
    Ecrit_Param.SEC = (((ParaSave.SEC / 10) * 16)+ParaSave.SEC %10);
    Ecrit_Param.MIN = (((ParaSave.MIN / 10) * 16)+ParaSave.MIN %10);
    Ecrit_Param.HEU = (((ParaSave.HEU / 10) * 16)+ParaSave.HEU %10);
    Ecrit_Param.SEM = ParaSave.SEM;
    Ecrit_Param.JOU = (((ParaSave.JOU / 10) * 16)+ParaSave.JOU %10);
    Ecrit_Param.MOI = (((ParaSave.MOI / 10) * 16)+ParaSave.MOI %10);
    Ecrit_Param.ANN = (((ParaSave.ANN / 10) * 16)+ParaSave.ANN %10);
    
    I2C_Write(&Ecrit_Param ,0x00,sizeof(S_ParamTemp));
}

void Control_alarme(void)
{
    static bool RTC_BAC_1_OK = false;
    static bool RTC_BAC_2_OK = false;
    static bool RTC_BAC_3_OK = false;
    static bool RTC_BAC_4_OK = false;
    if((Alarm_Bac_1.ACTIF == true) ||(Alarm_Bac_2.ACTIF == true)||(Alarm_Bac_3.ACTIF == true)||(Alarm_Bac_4.ACTIF == true))
    {
        Lecture_Paramettre();
        //si il est l'heurs de l arrosage du bac 1
        if((Local_Para.HEU == Alarm_Bac_1.HEU) && (Local_Para.MIN == Alarm_Bac_1.MIN)&&(Local_Para.SEM == Alarm_Bac_1.SEM)&&(Alarm_Bac_1.ACTIF == true)&&(RTC_BAC_1_OK == false))
        {
            Start_Arrosage(1);
            RTC_BAC_1_OK = true;
        }
        else
        {
            RTC_BAC_1_OK = false;
        }
        //si il est l'heurs de l arrosage du bac 2
        if((Local_Para.HEU == Alarm_Bac_2.HEU) && (Local_Para.MIN == Alarm_Bac_2.MIN)&&(Local_Para.SEM == Alarm_Bac_2.SEM)&&(Alarm_Bac_2.ACTIF == true)&&(RTC_BAC_2_OK == false))
        {
            Start_Arrosage(2);
            RTC_BAC_2_OK = true;
        }
        else
        {
            RTC_BAC_2_OK = false;
        }
        //si il est l'heurs de l arrosage du bac 3
        if((Local_Para.HEU == Alarm_Bac_3.HEU) && (Local_Para.MIN == Alarm_Bac_3.MIN)&&(Local_Para.SEM == Alarm_Bac_3.SEM)&&(Alarm_Bac_3.ACTIF == true)&&(RTC_BAC_3_OK == false))
        {
            Start_Arrosage(3);
            RTC_BAC_3_OK = true;
        }
        else
        {
            RTC_BAC_3_OK = false;
        }
        //si il est l'heurs de l arrosage du bac 4
        if((Local_Para.HEU == Alarm_Bac_4.HEU) && (Local_Para.MIN == Alarm_Bac_4.MIN)&&(Local_Para.SEM == Alarm_Bac_4.SEM)&&(Alarm_Bac_4.ACTIF == true)&&(RTC_BAC_4_OK == false))
        {
            Start_Arrosage(4);
            RTC_BAC_4_OK = true;
        }
        else
        {
            RTC_BAC_4_OK = false;
        }
    }
}

/* *****************************************************************************
 End of File
 */

/*******************************************************************************
 System Interrupts File

  File Name:
    system_interrupt.c

  Summary:
    Raw ISR definitions.

  Description:
    This file contains a definitions of the raw ISRs required to support the
    interrupt sub-system.

  Summary:
    This file contains source code for the interrupt vector functions in the
    system.

  Description:
    This file contains source code for the interrupt vector functions in the
    system.  It implements the system and part specific vector "stub" functions
    from which the individual "Tasks" functions are called for any modules
    executing interrupt-driven in the MPLAB Harmony system.

  Remarks:
    This file requires access to the systemObjects global data structure that
    contains the object handles to all MPLAB Harmony module objects executing
    interrupt-driven in the system.  These handles are passed into the individual
    module "Tasks" functions to identify the instance of the module to maintain.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2011-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_definitions.h"
#include "system_config.h"
#include "system/common/sys_common.h"
#include "app.h"
#include "system_definitions.h"
#include "Arrosage.h"
#include "Capteur_hultrason.h"
#include "GesPec12.h"
#include "RTC.h"
// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************
//initalisation des variable
uint16_t Temps_distance = 0;


     
 


 
 
 

 




 void __ISR(_UART_1_VECTOR, ipl1AUTO) _IntHandlerDrvUsartInstance0(void)
{
    DRV_USART_TasksTransmit(sysObj.drvUsart0);
    DRV_USART_TasksError(sysObj.drvUsart0);
    DRV_USART_TasksReceive(sysObj.drvUsart0);
}
 
 
 

void __ISR(_TIMER_1_VECTOR, ipl4AUTO) IntHandlerDrvTmrInstance0(void)
{
    //initalisation des variable
    static uint8_t start = 0;
    //attendre un moment au demarage
    if(start >= 50)
    {
         APP_UpdateState(APP_STATE_SERVICE_TASKS);
    }
    else
    {
        start++;
    }
   
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_1);
}
void __ISR(_TIMER_2_VECTOR, ipl3AUTO) IntHandlerDrvTmrInstance1(void)
{
    //initalisation des variable 
    static uint8_t compteur_puls = 0;
    //lecture du pec 12
    ScanPec12();
    //si OC du capteur a ultrason est activer 
    if(Compt_OC != 0)
    {
        //incremonter un compteur 
        compteur_puls++;
        if(compteur_puls == 1)
        {
            //activer le compteur pour avoir la distance
            Temps_distance = 1;
        }
        //apres 4 puls envoyez
        if(compteur_puls >= 5)
        {
            //stoper oc
            DRV_OC0_Stop();

        }
        //les pertubation sont stoper
        if(compteur_puls == 6)
        {
            //stoper l envois de oc
            Compt_OC = 0;
            compteur_puls = 0;
            //activer IC
            DRV_IC0_Start();      
        }
    }
    else
    {
        
    }
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_2);
}
void __ISR(_TIMER_3_VECTOR, ipl1AUTO) IntHandlerDrvTmrInstance2(void)
{
    //incementer le temp de la distance    
    if(Temps_distance >= 1)
    {
        Temps_distance++;
    }
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
}
void __ISR(_TIMER_4_VECTOR, ipl1AUTO) IntHandlerDrvTmrInstance3(void)
{
    static uint16_t Compteur_LED = 0;
    //activer le buzzer
    BUZZ_ALARMToggle();
    //faire clignotter la led erreur
    if(Compteur_LED >= 1000)
    {
        LED_ALARMToggle();
        Compteur_LED = 0;
    }
    Compteur_LED++;
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_4);
}
void __ISR(_TIMER_5_VECTOR, ipl2AUTO) IntHandlerDrvTmrInstance4(void)
{
    //initalisation des variables
    static uint16_t Compt_Bac_1 = 0;
    static uint16_t Compt_Bac_2 = 0;
    static uint16_t Compt_Bac_3 = 0;
    static uint16_t Compt_Bac_4 = 0;
    static uint8_t Compteur = 0;
    static uint16_t Compt_debit = 0;
    //tout les seconde
    if(Compteur >= 10)
    {
        LED_VIEToggle();
        Compteur = 0;
        //controler si il y a un bac qui dois etre arroser 
        Control_alarme();
        //controler si une des sond 1 est trop seche
        Contorle_Humi();
        //incrementer les temps pour arrosage
        Compt_Bac_1++;
        Compt_Bac_2++;
        Compt_Bac_3++;
        Compt_Bac_4++;
        Compt_debit++;
        //si le temps d'arrosage est bon
        if(Compt_Bac_1 >= Temps_Bac_1)
        {
            //remettre le compteur a 0
            Compt_Bac_1 = 0;
            //aller dans la machine d'etat d arrosage 
            Machine_etat_Arro(1);
        }
        //si le temps d'arrosage est bon
        if(Compt_Bac_2 >= Temps_Bac_2)
        {
            Compt_Bac_2 = 0;
             //aller dans la machine d'etat d arrosage 
            Machine_etat_Arro(2);
        }
        //si le temps d'arrosage est bon
        if(Compt_Bac_3 >= Temps_Bac_3)
        {
            Compt_Bac_3 = 0;
             //aller dans la machine d'etat d arrosage 
            Machine_etat_Arro(3);
        }
        //si le temps d'arrosage est bon
        if(Compt_Bac_4 >= Temps_Bac_4)
        {
            Compt_Bac_4 = 0;
             //aller dans la machine d'etat d arrosage 
            Machine_etat_Arro(4);
        }
        if(Compt_debit >= Temp_lec_debit)
        {
          Compt_debit = 0; 
          calcule_debit();  
        }
    }
    else
    {
        Compteur++;
    }
    
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
}
 
void __ISR(_INPUT_CAPTURE_3_VECTOR, ipl5AUTO) _IntHandlerDrvICInstance0(void)
{
    //sauvgarder le temps de la distance
    Save_Dis(Temps_distance);
    Temps_distance = 1;
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_INPUT_CAPTURE_3);
}

void __ISR(_OUTPUT_COMPARE_1_VECTOR, ipl6AUTO) _IntHandlerDrvOCInstance0(void)
{
    //interuption ne se produit jamais 
    
    
    static uint8_t compteur_puls = 0;
    
    //mettre un compteur pour envoyer que 4 pulse 
    compteur_puls++;
    if(compteur_puls == 1)
    {
        Temps_distance = 1;
    }
    if(compteur_puls >= 4)
    {
        compteur_puls = 0;
        DRV_OC0_Stop();

    }
    
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_OUTPUT_COMPARE_1);
}
/*******************************************************************************
 End of File
*/

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    Gest_Menu.h

  @Summary
    Brief description of the file.

  @Description
    cette librairy serre a faire le menu et les differant sous menu

 */
/* ************************************************************************** */


#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"
#include "Capteur_Humidite.h"
#include "peripheral/adc/plib_adc.h"
#include "Arrosage.h"
#include "Capteur_hultrason.h"
#include "LCD.h"


#ifndef Gest_Menu    /* Guard against multiple inclusion */
#define Gest_Menu

void Gest_Menu_Affiche(void);
extern bool Besoin_pompe;

#define INIT 0
#define REGLAGE 1
#define CONF 2
#define CAPTEUR 3
#define CONTROL 4
#define LEC_BAC 5


#define CONFI_BAC 9

#define CONFI_DIST 10

#define MODIF_BAC_SOND 11

#define MODIF_BAC_TEMPS_ARRO 12

#define MODIF_ALARM 13

#define LEC_TEMPS 14

#define CONFI_TEMPS_Sec 15
#define CONFI_TEMPS_Min 16
#define CONFI_TEMPS_Heu 17
#define CONFI_TEMPS_SEM 18
#define CONFI_TEMPS_Day 19
#define CONFI_TEMPS_MOI 20
#define CONFI_TEMPS_ANN 21
#define CONFI_TEMPS 22

#define CONFI_ALARM_Min 23
#define CONFI_ALARM_Heu 24
#define CONFI_ALARM_SEM 25

void Menu_Init(void);
void Menu_Reglage(void);
void Menu_Conf(void);
void Menu_Capteur(void);
void Menu_Controle(void);

void Menu_Lecture_Bac(void);

void Menu_Lecture_Temp(void);

void Menu_Confi_BAC(void);


void Menu_Confi_Distance(void);

void Menu_Mofid_Bac_Sond(void);

void Menu_Mofid_Bac_Temps_Arro(void);


void Menu_Mofid_Alarm(void);
void Menu_Conf_ALARM_Min(void);
void Menu_Conf_ALARM_Heu(void);
void Menu_Conf_ALARM_Sem(void);

void Menu_Conf_Temps(void);
void Menu_Conf_Temps_Sec(void);
void Menu_Conf_Temps_Min(void);
void Menu_Conf_Temps_Heu(void);
void Menu_Conf_Temps_Sem(void);
void Menu_Conf_Temps_Day(void);
void Menu_Conf_Temps_Moi(void);
void Menu_Conf_Temps_Ann(void);




#endif /* Gest_Menu */

/* *****************************************************************************
 End of File
 */

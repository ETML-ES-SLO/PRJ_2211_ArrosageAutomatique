/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    RTC.h

  @Summary
    Brief description of the file.

  @Description
 ce fichier serre a controler la RTC
 */
/* ************************************************************************** */

#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "system_config.h"
#include "system_definitions.h"
#include "system_config/default/framework/driver/i2c/drv_i2c_static_buffer_model.h"


#ifndef RTC    /* Guard against multiple inclusion */
#define RTC

#define LUNDI       0x01
#define MARDI       0x02
#define MERCREDI    0x04
#define JEUDI       0x08
#define VENDREDI    0x10
#define SAMEDI      0x20
#define DIMANCHE    0x40
typedef struct {
      uint8_t SEC;
      uint8_t MIN;
      uint8_t HEU;
      uint8_t SEM;
      uint8_t JOU;
      uint8_t MOI;
      uint8_t ANN;
} S_ParamTemp;

typedef struct {
    uint8_t SEM;
    uint8_t HEU;
    uint8_t MIN;
    bool ACTIF;
} S_ParamALARM;

typedef struct {
    uint8_t MIN;
    uint8_t HEU;
    uint8_t SEM;
} S_ParamALARMENvois;

enum day {Lundi = 0x02, Mardi = 0x04, Mercredi = 0x08, Jeudi = 0x10, Vendredi = 0x20, Samedi = 0x40, Dimanche = 0x01};

extern S_ParamALARM Alarm_Bac_1;
extern S_ParamALARM Alarm_Bac_2;
extern S_ParamALARM Alarm_Bac_3;
extern S_ParamALARM Alarm_Bac_4;
extern S_ParamTemp Local_Para;

void INIT_RTC(void);

void Lecture_Paramettre(void);
void Write_Paramettre_RTC(S_ParamTemp ParaSave);
void Control_alarme(void);


#endif /* RTC */

/* *****************************************************************************
 End of File
 */

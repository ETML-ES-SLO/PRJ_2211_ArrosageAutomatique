/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    Arrosage.c

  @Summary
    Brief description of the file.

  @Description
 se ficher serre a gere l'arrosage
 */
/* ************************************************************************** */
#include "Arrosage.h"
#include "RTC.h"
#include "Gest_Menu.h"

uint16_t Temps_Bac_1 = 0;
uint16_t Temps_Bac_2 = 0;
uint16_t Temps_Bac_3 = 0;
uint16_t Temps_Bac_4 = 0;

uint8_t etape_bac_1 = 0;
uint8_t etape_bac_2 = 0;
uint8_t etape_bac_3 = 0;
uint8_t etape_bac_4 = 0;

uint8_t Besoin_pompe1 = 0;
uint8_t Besoin_pompe2 = 0;
uint8_t Besoin_pompe3 = 0;
uint8_t Besoin_pompe4 = 0;


Temps_Consigne Temps_Consigne_Bac_1;
Temps_Consigne Temps_Consigne_Bac_2;
Temps_Consigne Temps_Consigne_Bac_3;
Temps_Consigne Temps_Consigne_Bac_4;

STR_Val_Humi_Bac Humi_Sond_Consigne_bac1;
STR_Val_Humi_Bac Humi_Sond_Consigne_bac2;
STR_Val_Humi_Bac Humi_Sond_Consigne_bac3;
STR_Val_Humi_Bac Humi_Sond_Consigne_bac4;

//mettre des valeur de sorti d'usine pour le bac 1
void Init_Arrosage_Bac_1(void)
{
    Temps_Consigne_Bac_1.X = 3;
    Temps_Consigne_Bac_1.Y = 5;
    Temps_Consigne_Bac_1.Z = 1;
    Humi_Sond_Consigne_bac1.Active = false;
    Humi_Sond_Consigne_bac1.Cap_1 = 20;
    Humi_Sond_Consigne_bac1.Cap_2 = 50;
    Humi_Sond_Consigne_bac1.Cap_3 = 30;
    Alarm_Bac_1.SEM = Lundi;
    Alarm_Bac_1.HEU = 12;
    Alarm_Bac_1.MIN = 00;
    Alarm_Bac_1.ACTIF = false;
}

//mettre des valeur de sorti d'usine pour le bac 2
void Init_Arrosage_Bac_2(void)
{
    Temps_Consigne_Bac_2.X = 3;
    Temps_Consigne_Bac_2.Y = 5;
    Temps_Consigne_Bac_2.Z = 1;
    Humi_Sond_Consigne_bac2.Active = false;
    Humi_Sond_Consigne_bac2.Cap_1 = 20;
    Humi_Sond_Consigne_bac2.Cap_2 = 50;
    Humi_Sond_Consigne_bac2.Cap_3 = 30;
    Alarm_Bac_2.SEM = Mardi;
    Alarm_Bac_2.HEU = 12;
    Alarm_Bac_2.MIN = 00;
    Alarm_Bac_2.ACTIF = false;
}

//mettre des valeur de sorti d'usine pour le bac 3
void Init_Arrosage_Bac_3(void)
{
    Temps_Consigne_Bac_3.X = 3;
    Temps_Consigne_Bac_3.Y = 5;
    Temps_Consigne_Bac_3.Z = 1;
    Humi_Sond_Consigne_bac3.Active = false;
    Humi_Sond_Consigne_bac3.Cap_1 = 20;
    Humi_Sond_Consigne_bac3.Cap_2 = 50;
    Humi_Sond_Consigne_bac3.Cap_3 = 30;
    Alarm_Bac_3.SEM = Mercredi;
    Alarm_Bac_3.HEU = 12;
    Alarm_Bac_3.MIN = 00;
    Alarm_Bac_3.ACTIF = false;
}

//mettre des valeur de sorti d'usine pour le bac 4
void Init_Arrosage_Bac_4(void)
{
    Temps_Consigne_Bac_4.X = 3;
    Temps_Consigne_Bac_4.Y = 5;
    Temps_Consigne_Bac_4.Z = 1;
    Humi_Sond_Consigne_bac4.Active = false;
    Humi_Sond_Consigne_bac4.Cap_1 = 20;
    Humi_Sond_Consigne_bac4.Cap_2 = 50;
    Humi_Sond_Consigne_bac4.Cap_3 = 30;
    Alarm_Bac_4.SEM = Jeudi;
    Alarm_Bac_4.HEU = 12;
    Alarm_Bac_4.MIN = 00;
    Alarm_Bac_4.ACTIF = false;
}

//commencer un arrosage du bac choisi
void Start_Arrosage(uint8_t Num_Bac)
{
    switch (Num_Bac)
        {
        case 1:
            //faire commencer la machine d'etat du bac 1
            etape_bac_1 = 1;
           break;
        case 2:
            //faire commencer la machine d'etat du bac 2
            etape_bac_2 = 1;
           break;   
        case 3:
            //faire commencer la machine d'etat du bac 3
          etape_bac_3 = 1;
           break;
        case 4:
            //faire commencer la machine d'etat du bac 4
            etape_bac_4 = 1;
           break;
        default:
           break;   
        }
  

}
//stoper l'arrosage du bac choisi
void Stop_Arrosage(uint8_t Num_Bac)
{
    switch (Num_Bac)
        {
            case 1:
                //stoper l arrosage du bac 1
                ELEC_VANN_1On();
                Besoin_pompe1 = 0;
                etape_bac_1 = 0;
                Temps_Bac_1 = 0;
               break;
            case 2:
                //stoper l arrosage du bac 2
                ELEC_VANN_2On();
                Besoin_pompe2 = 0;
                etape_bac_2 = 0;
                Temps_Bac_2 = 0;
               break;   
            case 3:
                //stoper l arrosage du bac 3
                ELEC_VANN_3On();
                Besoin_pompe3 = 0;
                etape_bac_3 = 0;
                Temps_Bac_3 = 0;

               break;
            case 4:
                //stoper l arrosage du bac 4
                ELEC_VANN_4On();
                Besoin_pompe4 = 0;
                etape_bac_4 = 0;
                Temps_Bac_4 = 0;

               break;
            default:
               break;   
        }
    //verifier si on dois allumer ou etindre le moteur
    Control_moteur();

}
//machine d'etat pour l arrosage
void Machine_etat_Arro(uint8_t Bac)
{
    //initalisation des variable
    uint8_t Besoin_pompe;
    STR_Val_Humi_Bac Val_Humi;
    STR_Val_Humi_Bac Consigne;
    Temps_Consigne Consigne_temps;
    uint16_t Temps_Bac;
    uint8_t etape_bac;
    
    //chois du bac utiliser
    switch (Bac)
    {
        case 1:
            //mettre les consigne du bac dans la machine d'etat 
            etape_bac = etape_bac_1;
            Temps_Bac = Temps_Bac_1;
            Besoin_pompe = Besoin_pompe1;
            Consigne = Humi_Sond_Consigne_bac1;
            Consigne_temps = Temps_Consigne_Bac_1;
            break;
        case 2:
            //mettre les consigne du bac dans la machine d'etat 
            etape_bac = etape_bac_2;
            Temps_Bac = Temps_Bac_2;
            Besoin_pompe = Besoin_pompe2;
           
            Consigne = Humi_Sond_Consigne_bac2;
            Consigne_temps = Temps_Consigne_Bac_2;
            break;
        case 3:
             //mettre les consigne du bac dans la machine d'etat 
            etape_bac = etape_bac_3;
            Temps_Bac = Temps_Bac_3;
            Besoin_pompe = Besoin_pompe3;
            
            Consigne = Humi_Sond_Consigne_bac3;
            Consigne_temps = Temps_Consigne_Bac_3;
            break;
        case 4:
             //mettre les consigne du bac dans la machine d'etat 
            etape_bac = etape_bac_4;
            Temps_Bac = Temps_Bac_4;
            Besoin_pompe = Besoin_pompe4;
            
            Consigne = Humi_Sond_Consigne_bac4;
            Consigne_temps = Temps_Consigne_Bac_4;
            break;    
        default:
            break;
    }
    
    switch (etape_bac)
    {
        case 0:
            //attendre que l'on commence un arrosage
           break;
        case 1:
                //demander d'allumer la pompe
                Besoin_pompe = 1;
                
                //activer l electrovanne choisi
                switch (Bac)
                {
                    case 1:
                        ELEC_VANN_1Off();
                        break;
                    case 2:
                        ELEC_VANN_2Off();
                        break;
                    case 3:
                        ELEC_VANN_3Off();
                        break;
                    case 4:
                        ELEC_VANN_4Off();
                        break;    
                    default:
                        break;
                }
                //mettre le temps d attende d'arrosage
                Temps_Bac = Consigne_temps.X;
                //aller dans l'etape 2
                etape_bac = 2;
                
           break;
        case 2:
			Temps_Bac = 0;
            //lecture du capteur d'humiditer du bac
            Val_Humi = Lecture_BAC_Cap_Humi(Bac);
            //si la sond 2 est asser humide
            if(Val_Humi.Cap_2 >= Consigne.Cap_2)
            {
                //dir que l'on a plus besoin de la pompe
                Besoin_pompe = 0;
                //stopper l electrovanne choisi
                switch (Bac)
                {
                    case 1:
                        ELEC_VANN_1On();
                        break;
                    case 2:
                        ELEC_VANN_2On();
                        break;
                    case 3:
                        ELEC_VANN_3On();
                        break;
                    case 4:
                        ELEC_VANN_4On();
                        break;    
                    default:
                        break;
                }
                //mettre le temps d'attende
                Temps_Bac = Consigne_temps.Y;
                //aller dans l'etat 3
                etape_bac = 3;
                
            }
           break;   
        case 3:
			
            //lecture du capteur d'humiditer du bac
            Val_Humi = Lecture_BAC_Cap_Humi(Bac);
            //si la sond 3 est humide
            if(Val_Humi.Cap_3 >= Consigne.Cap_3)
            {
                //re mettre tout a 0
                Temps_Bac = 0;
                etape_bac = 0;
            }
            else
            {
                //repartire dans l'etape 2
                etape_bac = 2;
                //dire que l on a besoin de la pompe
                Besoin_pompe = 1;
                //ouvrir l electrvanne
                switch (Bac)
                {
                    case 1:
                        ELEC_VANN_1Off();
                        break;
                    case 2:
                        ELEC_VANN_2Off();
                        break;
                    case 3:
                        ELEC_VANN_3Off();
                        break;
                    case 4:
                        ELEC_VANN_4Off();
                        break;    
                    default:
                        break;
                }
                //mettre le temps d arrosage 2
                Temps_Bac = Consigne_temps.Z;
           }
            break;
        default:
           break;   
    }
    //savgarder les valeur utiliser au bac qui correspond
    switch (Bac)
    {
        case 1:
            Besoin_pompe1 = Besoin_pompe;
            Temps_Bac_1 = Temps_Bac;
            etape_bac_1 = etape_bac;
            break;
        case 2:
            Besoin_pompe2 = Besoin_pompe;
            Temps_Bac_2 = Temps_Bac;
            etape_bac_2 = etape_bac;
            break;
        case 3:
            Besoin_pompe3 = Besoin_pompe;
            Temps_Bac_3 = Temps_Bac;
            etape_bac_3 = etape_bac;
            
            break;
        case 4:
            Besoin_pompe4 = Besoin_pompe;
            Temps_Bac_4 = Temps_Bac;
            etape_bac_4 = etape_bac;
            
            break;    
        default:
            break;
    }   
    //verifier si on dois allumer ou etindre le moteur
    Control_moteur();
}
void Control_moteur(void)
{
    //si un bac a besoin d'un moteur
    if((Besoin_pompe1 == 1) || (Besoin_pompe2 == 1) || (Besoin_pompe3 == 1) || (Besoin_pompe4 ==1)||(Besoin_pompe == 1))//((Besoin_pompe1 == 1) || (Besoin_pompe2 == 1) || (Besoin_pompe3 == 1) || (Besoin_pompe4 ==1)||(Besoin_pompe == 1)&&(controle_Pompe() == true))
    {
        //activer le moteur
        POMPE_RELAISOff();
        POMPE_HOn();
    }
    else
    {
        //stoper le moteur
        POMPE_RELAISOn();
        POMPE_HOff();
    }
}
/* *****************************************************************************
 End of File
 */

/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    LCD.c

  @Summary
    Brief description of the file.

  @Description
 cette librairy serre a la communication avec le ldc
 */
/* ************************************************************************** */

#include "LCD.h"


#define FUNCTION_SET        0b00111001
#define BIAS_SET            0b00010101
#define POWER_CONTROL       0b01010101
#define FOLLOWER_CONTROL    0b01101110
#define CONTRAST_SET        0b01110010
#define FUNCTION_SET_2      0b00111000
#define DISPLAY_ON_OFF      0b00001111
#define CLEAR_DISPLAY       0b00000001
#define ENTRY_MODE_SET      0b00000110


// Tableau contenant les adresses des lignes 1,2 et 3
const uint16_t taddrLines[4] = { 0x80,    
                                 0x80,    
                                 0x90,  
                                 0xA0};  


void LCD_INIT(void)
{
    //envoyer les differant commende d'initalisation du LCD
    LCD_Commande(FUNCTION_SET);
    delay_msCt(1);
    LCD_Commande(BIAS_SET);
    delay_msCt(1);
    LCD_Commande(POWER_CONTROL);
    delay_msCt(1);
    LCD_Commande(FOLLOWER_CONTROL);
    delay_msCt(1);
    LCD_Commande(CONTRAST_SET);
    delay_msCt(1);
    LCD_Commande(FUNCTION_SET_2);
    delay_msCt(1);
    LCD_Commande(DISPLAY_ON_OFF);
    delay_msCt(1);
    LCD_Commande(CLEAR_DISPLAY);
    delay_msCt(2);
    LCD_Commande(ENTRY_MODE_SET);
    delay_msCt(1);
    
}

void LCD_Commande(uint8_t Commende)
{
    //envoi d'une commande
    LATE = Commende;
    LCD_RSOff();
    LCD_RWOff();
    LCD_EOn();
    delay_usCt(30); 
    LCD_EOff(); 
}

void LCD_Write(uint8_t Text)
{
    //envoi d'un texte
    LATE = Text;
    LCD_RSOn();
    LCD_RWOff();
    LCD_EOn();
    delay_usCt(30); 
    LCD_EOff(); 
}


/*--------------------------------------------------------*/
void printf_lcd( const char *format,  ...)
{
    char Buffer[21];
    va_list args;
    va_start(args, format);

    vsprintf(Buffer, format, args);
    lcd_put_string((uint8_t*)Buffer);

    va_end(args);
}

/*--------------------------------------------------------*/
void lcd_put_string (uint8_t* DataChar)
{   
    while (*DataChar != 0)  
    { 
        LCD_Write(*DataChar);
        DataChar++;
    }
}
void lcd_gotoxy (uint8_t x, uint8_t y)
{
    if (x > 16)
    {
        x = 16;  
    }
    else if ( x < 0)
    {
        x = 0;  
    }
    if (y > 3)
    {
        y = 3;  
    }
    else if ( y < 1)
    {
        y = 1;  
    }
    LCD_Commande(taddrLines[y] + x);
}

void lcd_clear(void)
{
    LCD_Commande(CLEAR_DISPLAY);
    delay_msCt(2);
}

/* *****************************************************************************
 End of File
 */
